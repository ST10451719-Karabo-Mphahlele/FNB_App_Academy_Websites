import math 
import random
import datetime
import os
import sys

print (math.pi)
print(random.randint(0 ,10))
print(datetime.datetime.now())
print(os.getcwd())
print(sys.version)
fruits = ["apple pie", "banana cake", "chocolaate"]

print(fruits[0])

fruits[1] = "blueberry pie"

print(fruits)

fruits.append("kiwi")
print(fruits)

fruits.insert("orange juice")
print(fruits)

fruits.remove("kiwi")
print(fruits)

fruits.sort()
print(fruits)
import math_operations

print(math_operations.add(3 ,1))

print(math_operations.add(10 ,6))
import calculate

length = float(input("eneter the length of the rectangle: "))
width = float(input("Eneter the width  of the rectangle: "))

area = calculate.area(length , width)
perimeter = calculate.perimeter(length , width)

print(f"the are of the rectangle is : {area}")
print(f"the perimeter of the rectangle is:{perimeter}")
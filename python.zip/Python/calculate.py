def area(length , width):
    return length * width 

def perimeter(length ,wdith):
    return 2 * (length + wdith)
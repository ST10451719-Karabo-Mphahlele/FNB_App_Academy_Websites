   # Loops
fruits = ["apple", "Banana","cherry"]

for fruit in fruits :
    if fruit == "cherry":
        continue # Skips cherry and moves to the iteration
    print (fruit) 
    
    print ()
for fruit in fruits :
    if fruit == "cherry":
        pass #Placeholder no action is needed for cherry
    print (fruit) 
    
    numbers = [1,2,3,4,5,5]
    
    for number in numbers :
        print(number)
        
# Using a while loop to count from 1 to 5 

#count = 1 

#while count <= 5:
   # count += 1 # incremenets the country  by 1  
   # print(count)
    
 
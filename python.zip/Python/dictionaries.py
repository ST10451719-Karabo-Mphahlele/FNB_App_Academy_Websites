
my_dict = {'apple':3 ,'banana':4 , 'orange':2}

print(my_dict['apple'])

my_dict['grapes'] = 4
print(my_dict)

my_dict['banana'] = 7
print(my_dict)
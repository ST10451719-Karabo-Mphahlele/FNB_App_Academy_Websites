
x = 6

if x < 0:
    raise Exception("Sorry, no numbers below zero ")

try:
    print(x) 
 #'''except NameError:
  #  print ("Variable x is not defined") '''
except : 
    print ("Something went wrong")
finally :
    print ("The try except is finished")
    
    
try : 
    print(y)
except NameError:
    print("Variable y is not defined")
else :
    print ("The try except is finished again")
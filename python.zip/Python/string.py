
message = """Hello karabo 
is the coolest person"""

print(message)

message1 = 'Karabo'

#print(message1[0])
#print(message1[1])
#print(message1[2])

#print(message1.strip())#Remove leading and trailing whitespace
#print(message1.lower())# Convert all characters to lowercase

num = 3

print(3)
print(type(num))
# int num = 3
num1 = 3.14

print(type(num1))
# float num = 3.14

#Variable 
my_variable = 10
total_count = 0
user = 'John'
# Invalid 
second_variable = 10
user_name = 20

#Operators 
#Addititon (+)
#Subtraction(-)
#Mulitplication(*)
#Division (/)
#Modulus (%)
# Exponent (**)

x = 10 
y = 2 
c = -3
 
print(x+y)
print(x-y)
print(x*y)
print(x/y)
print(x%y)
print(5%2)
print(x**y)

str1 = 'Hello'
str2 = 'World'

print(str1 + " " + user + " " + str2)
print(str1 *3)

#Control Statements
num3 = -10

if num3 > 0:
    print ("This number is positive")
elif num3 ==0:
    print("This number is zero")
else :
    print ("This number is negitive")
    
    num4 = int (input("Enter the first number:"))
    num5 = int(input("Enter the second number:"))
    
    if num4 > num5:
        print(num4, "is greater than" , num5)
    elif num5 > num4 :
        print (num5 , "is greater then " , num4)
    else : 
        print ("Both numbers are equal")
        
     
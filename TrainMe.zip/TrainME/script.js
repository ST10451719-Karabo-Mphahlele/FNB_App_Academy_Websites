let currentWorkout = null;
        let currentExercise = 0;
        let currentTimer = 0;
        let timerInterval = null;
        let isPaused = false;

        const workouts = {
            HIIT: [
                { name: "Jumping Jacks", duration: 30, icon: "🤸" },
                { name: "Mountain Climbers", duration: 30, icon: "🏔️" },
                { name: "Burpees", duration: 30, icon: "💥" },
                { name: "Rest", duration: 30, icon: "😴" },
                { name: "High Knees", duration: 30, icon: "🦵" },
                { name: "Push-ups", duration: 30, icon: "𓀒" },
                { name: "Plank", duration: 30, icon: "🏋️" },
                { name: "Rest", duration: 30, icon: "😴" }
            ],
            Cardio: [
                { name: "Jog in Place", duration: 60, icon: "🏃" },
                { name: "High Knees", duration: 60, icon: "🦵" },
                { name: "Butt Kicks", duration: 60, icon: "🦵" },
                { name: "Rest", duration: 60, icon: "😴" },
                { name: "Jumping Jacks", duration: 60, icon: "🤸" },
                { name: "Side Steps", duration: 60, icon: "↔️" }
            ],
            Abs: [
                { name: "Crunches", duration: 45, icon: "🤸", reps: "15 reps" },
                { name: "Plank", duration: 45, icon: "🏋️" },
                { name: "Leg Raises", duration: 45, icon: "🦵", reps: "15 reps" },
                { name: "Rest", duration: 30, icon: "😴" },
                { name: "Russian Twists", duration: 45, icon: "🌪️", reps: "20 reps" },
                { name: "Bicycle Crunches", duration: 45, icon: "🚴", reps: "20 reps" }
            ],
             Legs: [
                { name: "Kettlebell Goblet Squats", duration: 45, icon: "🤸", reps: "15 reps" },
                { name: "Kettlebell Swings ", duration: 45, icon: "🏋️",reps: "15 reps" },
                { name: "Kettlebell Lunges ", duration: 45, icon: "🦵", reps: "10 reps" },
                { name: "Rest", duration: 30, icon: "😴" },
                { name: "Kettlebell Sumo Squats ", duration: 45, icon: "🌪️", reps: "20 reps" },
                { name: "Kettlebell Calf Raises", duration: 45, icon: "🚴", reps: "20 reps" }
            ]
        };

        function createParticles() {
            const particleContainer = document.getElementById('particles');
            
            for (let i = 0; i < 28; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 6 + 's';
                particle.style.animationDuration = (Math.random() * 3 + 3) + 's';
                particleContainer.appendChild(particle);
            }
        }

        function startWorkout(type) {
            currentWorkout = workouts[type];
            currentExercise = 0;
            
            document.getElementById('workoutMenu').classList.add('hidden');
            
            const display = document.getElementById('workoutDisplay');
            display.innerHTML = `
                <div class="workout-title">${type} Workout</div>
                <div class="get-ready">Get Ready!</div>
                <div class="exercise-icon">🔥</div>
            `;
            
            setTimeout(() => {
                showExercise();
            }, 4000);
        }

        function showExercise() {
            if (currentExercise >= currentWorkout.length) {
                completeWorkout();
                return;
            }

            const exercise = currentWorkout[currentExercise];
            const display = document.getElementById('workoutDisplay');
            
            display.innerHTML = `
                <div class="exercise-card">
                    <div class="exercise-icon">${exercise.icon}</div>
                    <div class="exercise-name">${exercise.name}</div>
                    ${exercise.reps ? `<div style="color: #ffd700; font-size: 1.2rem;">${exercise.reps}</div>` : ''}
                    <div class="timer-display" id="timer">${exercise.duration}</div>
                    <div class="progress-bar">
                        <div class="progress-fill" id="progress" style="width: 0%"></div>
                    </div>
                </div>
                <div class="control-buttons">
                    <button class="control-btn" onclick="pauseResume()">⏸️ Pause</button>
                    <button class="control-btn" onclick="skipExercise()">⏭️ Skip</button>
                    <button class="control-btn" onclick="stopWorkout()">⏹️ Stop</button>
                </div>
            `;

            currentTimer = exercise.duration;
            isPaused = false;
            startTimer();
        }

        function startTimer() {
            const timerDisplay = document.getElementById('timer');
            const progressBar = document.getElementById('progress');
            const totalDuration = currentWorkout[currentExercise].duration;
            
            timerInterval = setInterval(() => {
                if (!isPaused) {
                    currentTimer--;
                    timerDisplay.textContent = currentTimer;
                    
                    const progress = ((totalDuration - currentTimer) / totalDuration) * 100;
                    progressBar.style.width = progress + '%';
                    
                    if (currentTimer <= 0) {
                        clearInterval(timerInterval);
                        currentExercise++;
                        setTimeout(() => {
                            showExercise();
                        }, 1000);
                    }
                }
            }, 1000);
        }

        function pauseResume() {
            isPaused = !isPaused;
            const pauseBtn = document.querySelector('.control-btn');
            pauseBtn.textContent = isPaused ? '▶️ Resume' : '⏸️ Pause';
        }

        function skipExercise() {
            clearInterval(timerInterval);
            currentExercise++;
            showExercise();
        }

        function stopWorkout() {
            clearInterval(timerInterval);
            resetWorkout();
        }

        function completeWorkout() {
            const display = document.getElementById('workoutDisplay');
            display.innerHTML = `
                <div class="complete-message">🎉 Workout Complete! 🎉</div>
                <div class="exercise-icon">🏆</div>
                <div style="color: white; font-size: 1.2rem; margin: 20px 0;">
                    Great job! You crushed it! 💪
                </div>
                <button class="control-btn" onclick="resetWorkout()">🔄 New Workout</button>
            `;
        }

        function resetWorkout() {
            clearInterval(timerInterval);
            currentWorkout = null;
            currentExercise = 0;
            currentTimer = 0;
            isPaused = false;
            
            document.getElementById('workoutMenu').classList.remove('hidden');
            document.getElementById('workoutDisplay').innerHTML = '';
        }

        // Initialize particles on page load
        createParticles();